//Contruir tabla de Mutiplicar
 
var tabla = prompt(("¿que tabla deseas obtener?:"))

for (var i = 0; i < 11; i++) {
    console.log(""+tabla+" X "+i+" = "+(i*tabla));
}
